SETSUNA KESSEN - CREATOR KIT
Free to use for fan art, videos, thumbnails, streams, and Discord.

YOU CAN
- Use these files in TikToks, YouTube videos, streams, and fan art
- Use the profile pictures on Discord, Roblox groups, and socials
- Make your own fan art of any Setsuna Kessen fighter

PLEASE DON'T
- Sell these files or put them on merch
- Edit the logo or say your content is official
- Pass off concept art as real gameplay (label it "concept art")

Post your fan art and clips in the Discord to get featured on the site.
All art is concept art. Colors: Navy #010A13 / #0A1428, Gold #C8AA6E, Cream #F0E6D2.
